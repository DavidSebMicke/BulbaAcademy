using BulbasaurAPI.Models;
using BulbasaurAPI.Repository;
using Xunit.Abstractions;
using Xunit.Sdk;

namespace BulbasaurIntegrationTests.IntegrationTests
{
    public class CaregiverRepositoryTests : IClassFixture<TestDatabaseFixture>
    {
        private TestDatabaseFixture _databaseFixture { get; }

        private readonly ITestOutputHelper _testOutputHelper;

        public CaregiverRepositoryTests(TestDatabaseFixture databaseFixture, ITestOutputHelper testOutputHelper)
        {
            _databaseFixture = databaseFixture;
            _testOutputHelper = testOutputHelper;
        }

        [Fact]
        public async Task CreateCaregiver()
        {
            using var transaction = _databaseFixture.Connection.BeginTransaction();
            _testOutputHelper.WriteLine("Connstring: " + _databaseFixture.Connection.ConnectionString);

            using var context = _databaseFixture.CreateContext(transaction);

            var caregiverId = 0;

            var reqObject = new Caregiver()
            {
                SSN = "199701011234",
                FirstName = "FirstnameTest",
                LastName = "LastnameTest",
                HomeAddress = new Address("TestStreet", "TestCity", 12345),
                PhoneNumber = "0712345678",
                EmailAddress = "test@email.com"
            };

            var caregiverRepo = new CaregiverRepository(context);
            var caregiver = caregiverRepo.Create(reqObject);

            caregiverId = caregiver.Id;

            var fetchedCaregiver = await caregiverRepo.GetById(caregiverId);

            Assert.NotNull(fetchedCaregiver);
            Assert.Equal(reqObject.SSN, fetchedCaregiver.SSN);
            Assert.Equal(reqObject.FirstName, fetchedCaregiver.FirstName);
            Assert.Equal(reqObject.LastName, fetchedCaregiver.LastName);
            Assert.Equal(reqObject.HomeAddress.StreetAddress, fetchedCaregiver.HomeAddress.StreetAddress);
            Assert.Equal(reqObject.HomeAddress.City, fetchedCaregiver.HomeAddress.City);
            Assert.Equal(reqObject.HomeAddress.PostalCode, fetchedCaregiver.HomeAddress.PostalCode);
            Assert.Equal(reqObject.PhoneNumber, fetchedCaregiver.PhoneNumber);
            Assert.Equal(reqObject.EmailAddress, fetchedCaregiver.EmailAddress);
        }
    }
}