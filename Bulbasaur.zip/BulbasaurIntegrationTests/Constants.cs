﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BulbasaurIntegrationTests
{
    public static class Constants
    {
        public static int PeopleToGenerate { get; } = 10;
    }
}