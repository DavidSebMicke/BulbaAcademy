﻿namespace BulbasaurAPI.Authorization
{
    public enum UserAccessLevel
    {
        USER,
        EMPLOYEE,
        SEMIADMIN,
        ADMIN
    }
}