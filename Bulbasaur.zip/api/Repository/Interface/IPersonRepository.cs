﻿using BulbasaurAPI.Models;

namespace BulbasaurAPI.Repository.Interface
{
    public interface IPersonRepository : IBaseRepository<Person>
    {
    }
}
